/* eslint-disable prettier/prettier */
export const jwtConstants = {
  secret: 'secretKey',
  expiresIn: '16000s',
};
