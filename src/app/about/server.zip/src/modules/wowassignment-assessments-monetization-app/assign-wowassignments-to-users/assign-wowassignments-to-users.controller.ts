import { Controller } from '@nestjs/common';

@Controller('assign-wowassignments-to-users')
export class AssignWowassignmentsToUsersController {}
