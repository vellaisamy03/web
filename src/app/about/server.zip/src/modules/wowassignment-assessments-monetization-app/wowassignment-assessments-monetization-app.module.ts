import { Module } from '@nestjs/common';
import { AuthModule } from 'src/auth/auth.module';
import { CommonModule } from 'src/common/common.module';
import { AssignWowassignmentsToUsersController } from './assign-wowassignments-to-users/assign-wowassignments-to-users.controller';
import { AssignWowassignmentsToUsersService } from './assign-wowassignments-to-users/assign-wowassignments-to-users.service';

@Module({
  imports: [AuthModule, CommonModule],
  controllers: [
    AssignWowassignmentsToUsersController,
  ],
  providers: [
    AssignWowassignmentsToUsersService,
  ],
})
export class WowassignmentAssessmentsMonetizationAppModule {}
