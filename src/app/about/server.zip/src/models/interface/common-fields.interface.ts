/* eslint-disable prettier/prettier */ /* eslint-disable prettier/prettier */

export class CommonFieldsInterface {
  customer_id: number;
  country_code: string;
}
