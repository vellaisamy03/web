export enum ResponseMessageEnum {
    GET = "Data Get Successfully",
    ADD = " Data Saved Successfully",
    UPDATE = "Data Updated Successfully",
    DELETE = "Data Deleted Successfully",
}
