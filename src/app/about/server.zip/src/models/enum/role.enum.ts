/* eslint-disable prettier/prettier */
export enum Role {
  User = 'user',
  Admin = 'admin',
}
